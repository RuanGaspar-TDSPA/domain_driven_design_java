import entidades.Curso;
import entidades.Exercicio;
import entidades.Usuario;

public class Main {
    public static void main(String[] args) {
        System.out.println("Bem-vindo ao OneLinguo!");


        Usuario ana = new Usuario("Ana");


        Curso ingles = new Curso("Inglês");


        Exercicio exercicio = new Exercicio("Verbo To Do", "Nessa atividade vamos fixar conceitos aprendidos na aula de Verbo To Do", 3, "To Do 1", 9);


        adicionarExercicio(exercicio);
    }

    public static void adicionarExercicio(Exercicio exercicio) {

        if (exercicio != null) {
            System.out.println(exercicio.getNomeExercicio() + " - Exercício finalizado!");
        } else {
            System.out.println("Nenhum exercício para finalizar.");
        }
    }
}