package entidades;

import java.util.Objects;

public class Licao extends Curso {
    String titulo;
    String descricao;
    int nota;
    int duracao;



    public Licao() {
    }

    public Licao(String nome, String descricao, int duracao, String titulo, String descricao1, int nota, int duracao1) {
        super(nome, descricao, duracao);
        this.titulo = titulo;
        this.descricao = descricao1;
        this.nota = nota;
        this.duracao = duracao1;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public int getNota() {
        return nota;
    }

    public void setNota(int nota) {
        this.nota = nota;
    }

    @Override
    public int getDuracao() {
        return duracao;
    }

    @Override
    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Licao licao = (Licao) o;
        return nota == licao.nota && duracao == licao.duracao && Objects.equals(titulo, licao.titulo) && Objects.equals(descricao, licao.descricao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(titulo, descricao, nota, duracao);
    }

    @Override
    public String toString() {
        return "Licao{" +
                "titulo='" + titulo + '\'' +
                ", descricao='" + descricao + '\'' +
                ", nota=" + nota +
                ", duracao=" + duracao +
                '}';
    }
}

