package entidades;

import java.util.Objects;

public class Exercicio extends Licao {
    String nomeExercicio;
    String descricao;
    boolean resultado;



    public Exercicio() {
    }

    public Exercicio(String nome, String descricao, int duracao, String titulo, String descricao1, int nota, int duracao1, String nomeExercicio, String descricao2, boolean resultado) {
        super(nome, descricao, duracao, titulo, descricao1, nota, duracao1);
        this.nomeExercicio = nomeExercicio;
        this.descricao = descricao2;
        this.resultado = resultado;
    }

    public Exercicio(String verboToDo, String s, int i, String s1, int i1) {
    }

    public String getNomeExercicio() {
        return nomeExercicio;
    }

    public void setNomeExercicio(String nomeExercicio) {
        this.nomeExercicio = nomeExercicio;
    }

    @Override
    public String getDescricao() {
        return descricao;
    }

    @Override
    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }

    public boolean isResultado() {
        return resultado;
    }

    public void setResultado(boolean resultado) {
        this.resultado = resultado;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        if (!super.equals(o)) return false;
        Exercicio exercicio = (Exercicio) o;
        return resultado == exercicio.resultado && Objects.equals(nomeExercicio, exercicio.nomeExercicio) && Objects.equals(descricao, exercicio.descricao);
    }

    @Override
    public int hashCode() {
        return Objects.hash(super.hashCode(), nomeExercicio, descricao, resultado);
    }

    @Override
    public String toString() {
        return "Exercicio{" +
                "nomeExercicio='" + nomeExercicio + '\'' +
                ", descricao='" + descricao + '\'' +
                ", resultado=" + resultado +
                '}';
    }


}
