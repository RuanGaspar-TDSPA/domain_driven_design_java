package entidades;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

public class Usuario {
    private String nome;
    private String proficiencia;

    public Usuario() {
    }

    public Usuario(String nome, String proficiencia) {
        this.nome = nome;
        this.proficiencia = proficiencia;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getProficiencia() {
        return proficiencia;
    }

    public void setProficiencia(String proficiencia) {
        this.proficiencia = proficiencia;
    }

    public Usuario(String nome) {
        this.nome = nome;

    }

    public String getNome() {
        return this.nome;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Usuario usuario = (Usuario) o;
        return Objects.equals(nome, usuario.nome) && Objects.equals(proficiencia, usuario.proficiencia);
    }

    @Override
    public int hashCode() {
        return Objects.hash(nome, proficiencia);
    }

    @Override
    public String toString() {
        return "Usuario{" +
                "nome='" + nome + '\'' +
                ", proficiencia='" + proficiencia + '\'' +
                '}';
    }
}